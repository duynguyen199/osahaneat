package com.cybersoft.osahaneat.service.imp;

import com.cybersoft.osahaneat.dto.UserDTO;

import java.util.List;

public interface UserServiceImp {

    List <UserDTO> getAllUser();

}
