package com.cybersoft.osahaneat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OsahaneatApplicationTests {

	@Test
	void contextLoads() {
	}

}
